/*
    CIT 281 Project 2
    Name: Veer Chulki
*/
// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

const alphabet = "abcdefghijklmnopqrstuvwxyz";
const length = getRandomInteger(5, 26); // max is exclusive
let result = "";

for (let i = 0; i < length; i++) {
    result += alphabet[getRandomInteger(0, alphabet.length)];
}

const randomStr = getRandomString(10, 20);
console.log(randomStr);
console.log(getSortedString(randomStr));


// Returns a single random lowercase letter
function getRandomLetter() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    return alphabet.charAt(Math.floor(Math.random() * alphabet.length));
  }
  
// Returns a random string between minLength and maxLength
function getRandomString(minLength, maxLength) {
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    let result = "";
    for (let i = 0; i < length; i++) {
      result += getRandomLetter();
    }
    return result;
  }

// Returns a string with characters sorted in ascending order
function getSortedString(string) {
    return string.split('').sort().join('');
  }
  
  