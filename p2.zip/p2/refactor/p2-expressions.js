// CIT 281 Project 2
// Name: Veer Chulki

// Returns a single random lowercase letter
const getRandomLetter = function() {
    const alphabet = "abcdefghijklmnopqrstuvwxyz";
    return alphabet.charAt(Math.floor(Math.random() * alphabet.length));
  };
  
  // Returns a random string between minLength and maxLength
  const getRandomString = function(minLength, maxLength) {
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    let result = "";
    for (let i = 0; i < length; i++) {
      result += getRandomLetter();
    }
    return result;
  };
  
  // Returns a string with characters sorted in ascending order
  const getSortedString = function(string) {
    return string.split('').sort().join('');
  };
  
  // Example usage
  const randomStr = getRandomString(10, 20);
  console.log(randomStr);
  console.log(getSortedString(randomStr));
  